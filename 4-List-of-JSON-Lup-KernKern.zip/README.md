1. Include **axios** in your `index.html`

2. When the page is ready (see: https://developer.mozilla.org/en-US/docs/Web/API/Window/DOMContentLoaded_event), load in the users data from the following URL:

 https://raw.githubusercontent.com/kunxin-chor/data-files-and-stuff/master/users.json

3. Display **only** the first name, and last name and email address of each user in an **unordered list**. You have to use _list rendering techniques_. Here's an example of how the output should be like:
<ul>
  <li>Krish Lee (krish.lee@learningcontainer.com)</li>
  <li>racks jacson (racks.jacson@learningcontainer.com)</li>
  <li>denial roast (denial.roast@learningcontainer.com)</li>
</ul>



