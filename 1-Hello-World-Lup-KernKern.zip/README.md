Follow the setup steps below:

1. Add axios to `index.html`

2. Using `axios.get()`, load in the content of the file from: 

```
https://4geeksacademy.github.io/exercise-assets/txt/hello.txt
```

4. Display the content of the file inside your website (you can set the innerHTML of the `<body>` element)