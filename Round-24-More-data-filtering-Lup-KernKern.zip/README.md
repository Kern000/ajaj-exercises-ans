**Step 1:** Include _axios_ into the website

**Step 2:** When a button is pressed, read in the first ten results from the JSON file below:

 https://raw.githubusercontent.com/robconery/json-sales-data/master/data/products.json

**Step 3:** Find all the possible composers there are and put them into an array (i.e, the array should have no duplicates, and have all the composers from the JSON)

**Step 4:** Display the composers in a <select> dropdown, and allow the user to select a composer from the list

**Step 5:** Once the user has selected a composer from the list, display the albums composed by that composer.