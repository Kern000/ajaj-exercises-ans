# Instructions

**Important**: Do not modify the `mocha` and `chai` scripts, css and `<div>`

There is automatic testing for this question. Press [Run] or if you open in new tab, reload the page, to see if the test cases passed. 

1. In `script.js`, use `axios` to read in the content of `profile.json`
2. Display the name, gender, age and hobbies of the user.
3. Make sure to display hobbies as an unordered list.

# Hint
The expected output below is generated with the following html:
```
  <h1>User Profile</h1>
  <ul>
    <li>Username: <span id="username">Jon Snow</span></li>
    <li>Age: <span id="age">32</span></li>
    <li>Gender: <span id="gender">M</span></li>
    <li>Hobbies: <span id="hobbies">
      <ul>
        <li>hiking</li>
        <li>swordfighting</li>
        <li>wolf rearing</li>
      </ul>
    </span></li>
  </ul>
  ```

# Expected Output
![image](image.png)