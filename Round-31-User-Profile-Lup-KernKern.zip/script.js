window.addEventListener("DOMContentLoaded", function(){
  // write your code here
})