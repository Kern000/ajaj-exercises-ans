# Instructions  

To run the automated test, **reload the page** and then click on the _Run Test_ button.

  ## Steps
  1. Use `axios` to read in the content of `employees.json` 
  2. Display each employee on one row, showing the ID, name and position of the employee.

## Expected Output
![image](image.png)